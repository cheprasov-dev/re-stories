self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d62a7d5aa670121740fa0457ce153b6a",
    "url": "/index.html"
  },
  {
    "revision": "4476cce5f245412cf483",
    "url": "/static/css/2.cdee455b.chunk.css"
  },
  {
    "revision": "76795577d41492ae8a48",
    "url": "/static/css/main.203fc2e6.chunk.css"
  },
  {
    "revision": "4476cce5f245412cf483",
    "url": "/static/js/2.f02b38fa.chunk.js"
  },
  {
    "revision": "29eb69a08ea4198f7b46e1db8a3d5045",
    "url": "/static/js/2.f02b38fa.chunk.js.LICENSE.txt"
  },
  {
    "revision": "76795577d41492ae8a48",
    "url": "/static/js/main.98b4f7dd.chunk.js"
  },
  {
    "revision": "3c0bf5e688fb521354db",
    "url": "/static/js/runtime-main.6df0345a.js"
  },
  {
    "revision": "819de83ed7e5f6c047418a597256da5b",
    "url": "/static/media/Mark.819de83e.svg"
  },
  {
    "revision": "5450a62bd47c20ac6a1daa9916fe8e5b",
    "url": "/static/media/animals.5450a62b.jpeg"
  },
  {
    "revision": "564ddab61ba95b47eddb82e13a66e64a",
    "url": "/static/media/arrow.564ddab6.svg"
  },
  {
    "revision": "a5831b1d97bcbb43c37e93161eec0899",
    "url": "/static/media/art.a5831b1d.jpeg"
  },
  {
    "revision": "6a5879111acfb4677720f18cd64ef0f1",
    "url": "/static/media/auto.6a587911.jpeg"
  },
  {
    "revision": "e713387e6213cef41fc8edaba05d2c6a",
    "url": "/static/media/backgroundPage.e713387e.svg"
  },
  {
    "revision": "a8aece5129e1399ae2932ccf47c8ea01",
    "url": "/static/media/beauty.a8aece51.jpeg"
  },
  {
    "revision": "00fcb4168e602b53d381581a0bba7eda",
    "url": "/static/media/bell.00fcb416.svg"
  },
  {
    "revision": "41b74d66724e92de8bf059edee3094be",
    "url": "/static/media/bloggers.41b74d66.jpeg"
  },
  {
    "revision": "795e6b5310470949f850d46d9c7d7ef3",
    "url": "/static/media/brands.795e6b53.jpeg"
  },
  {
    "revision": "2e0ec58aacc2c764439884da9a5a3378",
    "url": "/static/media/entertainment.2e0ec58a.jpeg"
  },
  {
    "revision": "786e05ca11b144ce6c0b77d882b73410",
    "url": "/static/media/firstPrize.786e05ca.svg"
  },
  {
    "revision": "2857d180e309c1e443024c6ea75dffe0",
    "url": "/static/media/food.2857d180.jpeg"
  },
  {
    "revision": "caa7a745d612a09bc39f116980d66a2a",
    "url": "/static/media/games.caa7a745.jpeg"
  },
  {
    "revision": "192e6d9a6a6e632cc4258f6c9ec30b7d",
    "url": "/static/media/goldenLaurels.192e6d9a.svg"
  },
  {
    "revision": "224bea3d7c8440f602e28fec9a45db54",
    "url": "/static/media/medicine.224bea3d.png"
  },
  {
    "revision": "84c0714b173c3bf42f0ff4729035bdc8",
    "url": "/static/media/music.84c0714b.jpeg"
  },
  {
    "revision": "fbc501372f7b4363a9f07b69aa4c1427",
    "url": "/static/media/news.fbc50137.jpeg"
  },
  {
    "revision": "bf42c682053047edef89835183c73f36",
    "url": "/static/media/participants.bf42c682.svg"
  },
  {
    "revision": "33b4d220472a19280081266485ddac77",
    "url": "/static/media/people.33b4d220.svg"
  },
  {
    "revision": "32d2a7c8ec62aba305b6f734be46d40e",
    "url": "/static/media/personal_account.32d2a7c8.svg"
  },
  {
    "revision": "3dee9af36a55aecc05d353e65aae9205",
    "url": "/static/media/radio.3dee9af3.jpeg"
  },
  {
    "revision": "8086a40d493beabbbfea9bc74f8fb51f",
    "url": "/static/media/rubik-mono-one-v8-latin-regular.8086a40d.ttf"
  },
  {
    "revision": "bbb689257ad63a013fb7ebc7d35b033a",
    "url": "/static/media/rubik-mono-one-v8-latin-regular.bbb68925.woff2"
  },
  {
    "revision": "c650c77cc342c1086203885da580ae93",
    "url": "/static/media/rubik-mono-one-v8-latin-regular.c650c77c.eot"
  },
  {
    "revision": "c6bfb5974c7d69b6e92a2b2f7b21e8fe",
    "url": "/static/media/rubik-mono-one-v8-latin-regular.c6bfb597.woff"
  },
  {
    "revision": "cf080b9e53faac690b6b4e1d25a90220",
    "url": "/static/media/rubik-mono-one-v8-latin-regular.cf080b9e.svg"
  },
  {
    "revision": "01dcb7173a4f25a43d2234ccc615dac1",
    "url": "/static/media/rubik-v9-latin_cyrillic-500.01dcb717.ttf"
  },
  {
    "revision": "8d230c689f03dbbc340ae5f3fb1c6465",
    "url": "/static/media/rubik-v9-latin_cyrillic-500.8d230c68.eot"
  },
  {
    "revision": "976279631c785294cc504f7b159a2f90",
    "url": "/static/media/rubik-v9-latin_cyrillic-500.97627963.woff2"
  },
  {
    "revision": "a95d34eb704a1d7d53a01f2df3ffa8dc",
    "url": "/static/media/rubik-v9-latin_cyrillic-500.a95d34eb.svg"
  },
  {
    "revision": "ebbea0f924ee40e780f41eccf94a089a",
    "url": "/static/media/rubik-v9-latin_cyrillic-500.ebbea0f9.woff"
  },
  {
    "revision": "2be858f1ac5d2c207f3ee41a7efd7aa7",
    "url": "/static/media/rubik-v9-latin_cyrillic-700.2be858f1.eot"
  },
  {
    "revision": "35cbdba130539ae1adf867948d1153ce",
    "url": "/static/media/rubik-v9-latin_cyrillic-700.35cbdba1.woff"
  },
  {
    "revision": "3fc49e126e615bf2c4dbc8d93e9c6522",
    "url": "/static/media/rubik-v9-latin_cyrillic-700.3fc49e12.ttf"
  },
  {
    "revision": "9c20ee633a2ad7ffdb6e26e0bbf58121",
    "url": "/static/media/rubik-v9-latin_cyrillic-700.9c20ee63.woff2"
  },
  {
    "revision": "e903c17480ac7df2822c58068d7aa5a9",
    "url": "/static/media/rubik-v9-latin_cyrillic-700.e903c174.svg"
  },
  {
    "revision": "03f3e06aa9d3032905a138af88dc98fd",
    "url": "/static/media/rubik-v9-latin_cyrillic-regular.03f3e06a.ttf"
  },
  {
    "revision": "476add9777c6dfe1f187a3a769780f20",
    "url": "/static/media/rubik-v9-latin_cyrillic-regular.476add97.woff"
  },
  {
    "revision": "8d9ea4e577aab6336d522850543fb65c",
    "url": "/static/media/rubik-v9-latin_cyrillic-regular.8d9ea4e5.svg"
  },
  {
    "revision": "9d4f1076593ae2abc9bab33c62f9d3cf",
    "url": "/static/media/rubik-v9-latin_cyrillic-regular.9d4f1076.eot"
  },
  {
    "revision": "fca53e835decd8ce3672ac932af4e4d1",
    "url": "/static/media/rubik-v9-latin_cyrillic-regular.fca53e83.woff2"
  },
  {
    "revision": "396858c05222cdc8de273e6b7b2c2a23",
    "url": "/static/media/science.396858c0.jpeg"
  },
  {
    "revision": "e7b71b5e7f3724c00f57dedef65bc786",
    "url": "/static/media/secondPrize.e7b71b5e.svg"
  },
  {
    "revision": "c234249e1197a7ed1eeb2a1da17d1177",
    "url": "/static/media/shops.c234249e.jpeg"
  },
  {
    "revision": "841fcd17af1d9ce8bd19f2b2a278d0aa",
    "url": "/static/media/silverLaurels.841fcd17.svg"
  },
  {
    "revision": "eef8d9f1e097ff3f7b6301caeec8f230",
    "url": "/static/media/sport.eef8d9f1.jpeg"
  },
  {
    "revision": "e3d52c4f715581c2b6c31ae909d27439",
    "url": "/static/media/stories.e3d52c4f.svg"
  },
  {
    "revision": "54cf344168be8ca334ab5e97b6ad4d3e",
    "url": "/static/media/thirdPrize.54cf3441.svg"
  },
  {
    "revision": "15fd9e2c46c594f42c8162b00b752e77",
    "url": "/static/media/timer.15fd9e2c.svg"
  },
  {
    "revision": "09c81c25b3ea2895063112bb8e4efcfb",
    "url": "/static/media/timerGold.09c81c25.svg"
  },
  {
    "revision": "a5a4bd56b664b5aa650f7eba95fd0b27",
    "url": "/static/media/trainingConditions.a5a4bd56.png"
  },
  {
    "revision": "103fc606b14e662ecfd30a3087aa7ff5",
    "url": "/static/media/trainingContests.103fc606.png"
  },
  {
    "revision": "23cc62a0d5ae2ca818dd9ae1c90ef6be",
    "url": "/static/media/trainingPrizes.23cc62a0.png"
  },
  {
    "revision": "eb540d512f93c10ef7c3190fe9ffcf53",
    "url": "/static/media/travels.eb540d51.jpeg"
  }
]);